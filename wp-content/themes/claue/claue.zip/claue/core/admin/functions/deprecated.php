<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Deprecated framework functions from past framework versions. You shouldn't use these
 * functions and look for the alternatives instead. The functions will be removed in a later version.
 *
 */
/**
 *
 * Check for google font
 *
 * @since 1.0.0
 * @deprecated 1.0.0
 *
 */
function cs_is_googe_font() {
  _deprecated_function( __FUNCTION__, '1.0.0' );
}


/**
 *
 * Safe web fonts
 *
 * @since 1.0.0
 * @deprecated 1.0.0
 *
 */
function cs_get_websafe_fonts() {
  _deprecated_function( __FUNCTION__, '1.0.0' );
}

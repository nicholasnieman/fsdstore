<?php
/**
 * The template for displaying archive pages.
 *
 * @since   1.0.0
 * @package Claue
 */

get_template_part( 'index' );
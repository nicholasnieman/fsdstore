Theme Name: Claue
Theme URI: http://www.janstudio.net/claue
Theme Documentation: http://www.janstudio.net/claue/document
Theme Support: http://support.janstudio.net/forums/forum/themes-support/claue/
